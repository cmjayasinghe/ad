#include <Arduino.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <Servo.h>

LiquidCrystal_I2C lcd(0x27, 16, 2);
Servo servoMotor;

int leds[] = {2, 3, 4, 5, 6, 7, 8};
int startButton = 9;
int luckButton = 10;
int servoPin = 11;

int currentLed = 0;
int direction = 1;

int attempts = 0;
int wins = 0;

bool gameStarted = false;

void turnOffAllLeds() {
  for (int i = 0; i < 7; i++) {
    digitalWrite(leds[i], LOW);
  }
}

void showStatus(String line1, String line2) {
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print(line1);
  lcd.setCursor(0, 1);
  lcd.print(line2);
}

void setup() {
  for (int i = 0; i < 7; i++) {
    pinMode(leds[i], OUTPUT);
  }

  pinMode(startButton, INPUT_PULLUP);
  pinMode(luckButton, INPUT_PULLUP);

  servoMotor.attach(servoPin);
  servoMotor.write(0);

  lcd.init();
  lcd.backlight();

  showStatus("Press Start", "Wins:0 Att:0");
}

void loop() {
  // Start the game
  if (!gameStarted && digitalRead(startButton) == LOW) {
    gameStarted = true;
    delay(300);
    showStatus("Game Started", "Press Luck");
  }

  // Run LED pattern only after start
  if (gameStarted) {
    turnOffAllLeds();
    digitalWrite(leds[currentLed], HIGH);

    delay(150);

    // Check luck button
    if (digitalRead(luckButton) == LOW) {
      attempts++;

      if (currentLed == 3) {   // 4th LED
        wins++;
        showStatus("You Win!", "Wins:" + String(wins));
      } else {
        showStatus("You Lose!", "Att:" + String(attempts));
      }

      delay(1000);

      // If 3 wins -> open servo
      if (wins == 3) {
        showStatus("3 Wins!", "Prize Open");
        servoMotor.write(90);
        while (true);
      }

      // If 3 attempts used and not 3 wins
      if (attempts == 3) {
        showStatus("Game Over", "Try Again");
        while (true);
      }

      showStatus("Press Start", "Wins:" + String(wins) + " Att:" + String(attempts));
      gameStarted = false;
    }

    // Move LED left-right
    currentLed = currentLed + direction;

    if (currentLed == 6) {
      direction = -1;
    }

    if (currentLed == 0) {
      direction = 1;
    }
  }
}